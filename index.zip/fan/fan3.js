let currentQuestion = -1; // หน้าแรก

const questions = [
  {
    question: "เลนชอบกินอะไรที่สุด?",
    options: [
      { text: "ก๋วยเตี๋ยว", correct: true },
      { text: "ราดหน้า", correct: false },
      { text: "ข้าวผัด", correct: false },
    ],
  },
  {
    question: "เค้าเกิดวันไหน?",
    options: [
      { text: "8 สิงหา 2551", correct: false },
      { text: "2 กันยา 2551", correct: true },
      { text: "9 มกรา 2551", correct: false },
    ],
  },
  {
    question: "เลนชอบสีอะไร?",
    options: [
      { text: "ฟ้า", correct: false },
      { text: "ขาว", correct: true },
      { text: "ดำ", correct: false },
    ],
  },
  {
    question: "เลนเป็นคนที่ไหนนน?",
    options: [
      { text: "มอญ", correct: true },
      { text: "เขมร", correct: false },
      { text: "ลาว", correct: false },
    ],
  },
  {
    question: "เลนชอบรถแบบไหนมากที่สุดดด?",
    options: [
      { text: "110i", correct: false },
      { text: "Civic", correct: false },
      { text: "R34", correct: true },
    ],
  },
];

// สร้าง element หัวใจตกพื้นหลัง (ซ่อนตอนแรก)
function createBackgroundHearts() {
  if (document.getElementById("background-hearts")) return;
  const bgContainer = document.createElement("div");
  bgContainer.id = "background-hearts";
  document.body.appendChild(bgContainer);

  const colors = ["#a0d8f7", "#9adcf8", "#81c3f5", "#b0e0ff"];

  function createHeart() {
    const heart = document.createElement("div");
    heart.textContent = "💙";
    heart.style.position = "absolute";
    heart.style.fontSize = Math.floor(Math.random() * 20 + 10) + "px";
    heart.style.left = Math.random() * 100 + "vw";
    heart.style.top = "-30px";
    heart.style.opacity = Math.random() * 0.5 + 0.3;
    heart.style.color = colors[Math.floor(Math.random() * colors.length)];
    heart.style.animation = `bgFall ${5 + Math.random() * 5}s linear forwards`;
    bgContainer.appendChild(heart);

    setTimeout(() => {
      heart.remove();
    }, 10000);
  }
  setInterval(createHeart, 400);
}

// แสดง/ซ่อนหัวใจพื้นหลัง
function toggleBackgroundHearts(show) {
  const bg = document.getElementById("background-hearts");
  if (!bg) return;
  bg.style.display = show ? "block" : "none";
}

// ข้อความงอนเด้งกลางจอ 2 วิ
function showAngryMessage() {
  if (document.getElementById("angry-msg")) return;

  const msg = document.createElement("div");
  msg.id = "angry-msg";
  msg.textContent = "งอนแล้วนะ! 😠";
  Object.assign(msg.style, {
    position: "fixed",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    background: "#f56565",
    color: "white",
    padding: "1.5rem 2rem",
    borderRadius: "1rem",
    fontSize: "1.5rem",
    fontWeight: "bold",
    zIndex: 9999,
    boxShadow: "0 0 10px rgba(0,0,0,0.3)",
  });

  document.body.appendChild(msg);

  setTimeout(() => {
    msg.remove();
  }, 2000);
}

// หน้าแรก
function showIntro() {
  currentQuestion = -1;
  toggleBackgroundHearts(false);
  document.getElementById("page-content").innerHTML = `
    <h1>อ้วนจ๋าาาาาา💙</h1>
    <p class="desc">เค้ามีอะไรให้เล่นด้วยยย ✨</p>
    <p class="desc">เค้าจะให้เธอตอบคำถาม 5 ข้อง่ายๆ</p>
    <button onclick="startQuestions()">ไปกันเยยยย~ 💙</button>
  `;
}

function startQuestions() {
  currentQuestion = 0;
  showQuestion();
}

function showQuestion() {
  if (currentQuestion < questions.length) {
    const q = questions[currentQuestion];

    const optionsHTML = q.options
      .map((opt, idx) => `<button onclick="checkAnswer(${idx})">${opt.text}</button>`)
      .join("");

    document.getElementById("page-content").innerHTML = `
      <h1>คำถามข้อที่ ${currentQuestion + 1} 💬</h1>
      <p class="desc">${q.question}</p>
      <div class="options-row">
        ${optionsHTML}
      </div>
    `;
  } else if (currentQuestion === questions.length) {
    // ข้อความความในใจ (ยังไม่เปิดหัวใจตก)
    toggleBackgroundHearts(false);
    document.getElementById("page-content").innerHTML = `
      <h1>เค้าอยากบอกเธอว่า... 💙</h1>
      <p class="desc">เธอเป็นคนที่ดีและน่ารักมากกกก สำหรับเค้านะ อยากอยู่กับเธอไปตลอดเลยย</p>
      <button onclick="showFinalQuestion()">สิ่งที่เค้าอยากบอกเธอก็คือ... 💙</button>
    `;
  } else if (currentQuestion === questions.length + 1) {
    // ขอเป็นแฟน (ข้อ 6) พร้อมเปิดหัวใจตกพื้นหลัง
    toggleBackgroundHearts(true);
    document.getElementById("page-content").innerHTML = `
      <h1>เป็นแฟนกับเค้ามั้ยคะ~? 💙</h1>
      <p class="desc">
      <button onclick="acceptLove()">เป็น 💙</button>
      <button id="runaway" onmouseover="moveButton()">ไม่อะ</button>
    `;
  }
}

function showFinalQuestion() {
  currentQuestion++;
  showQuestion();
}

function checkAnswer(selectedIndex) {
  const correct = questions[currentQuestion].options[selectedIndex].correct;
  if (correct) {
    currentQuestion++;
    showQuestion();
  } else {
    showAngryMessage();
  }
}

function moveButton() {
  const btn = document.getElementById("runaway");
  if (!btn) return;

  const container = document.getElementById("page-content");
  const maxX = container.clientWidth - btn.offsetWidth;
  const maxY = container.clientHeight - btn.offsetHeight;

  btn.style.position = "absolute";
  btn.style.left = Math.random() * maxX + "px";
  btn.style.top = Math.random() * maxY + "px";
}

function acceptLove() {
  document.getElementById("page-content").innerHTML = `
    <h1>รักนะคะแฟนนนน  💖</h1>
    <p class="desc">ขอบคุณที่ตอบตกลงนะอ้วน หลังจากนี้เค้าจะคอยดูแลเธอเองนะและจะคอยซัพพอร์ตเธอ จะอยู่เป็นกำลังใจให้เธอ 
    ต่อไปนี้เธอไม่ได้อยู่คนเดียวแล้วนะมีอะไรบอกเค้ามาเลย สัญญาเค้าจะเป็นแฟนที่ดีให้เธอเอง 
    รักแฟนที่ฉุดดด~ ✨</p>
    <div id="hearts-container"></div>
  `;

  createFallingHearts();
}

// หัวใจตกตอนตอบตกลง
function createFallingHearts() {
  const container = document.getElementById("hearts-container");
  if (!container) return;

  const colors = ["#ff6b81", "#ff4757", "#ff7f50", "#ff3f34"];
  const totalHearts = 30;

  for (let i = 0; i < totalHearts; i++) {
    const heart = document.createElement("div");
    heart.textContent = "❤️";
    heart.style.position = "absolute";
    heart.style.fontSize = `${Math.floor(Math.random() * 20) + 20}px`;
    heart.style.color = colors[Math.floor(Math.random() * colors.length)];
    heart.style.left = Math.random() * 100 + "%";
    heart.style.top = "-50px";
    heart.style.opacity = Math.random() * 0.8 + 0.2;
    heart.style.animation = `fall ${3 + Math.random() * 3}s linear forwards`;
    heart.style.animationDelay = (Math.random() * 3) + "s";

    container.appendChild(heart);

    setTimeout(() => {
      heart.remove();
    }, 7000);
  }
}

// เริ่มต้นแอปเมื่อโหลดหน้าเว็บ
window.onload = () => {
  createBackgroundHearts();
  showIntro();
};
